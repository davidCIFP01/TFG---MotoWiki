
# IDEAS PARA TFG

- Gestor de Plantillas para PortFolios.

- Gestor de APIs.

- Página de Motos (Estilo Wikipedia)

- Pagina sobre Pokemon (Con Api de Pokemon)