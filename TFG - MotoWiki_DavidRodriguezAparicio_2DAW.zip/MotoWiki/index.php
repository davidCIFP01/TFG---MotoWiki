
<?php

header("Location: ./controller/inicio.php");

?>