INSERT INTO fabricante (nombreFabricante, paisOrigen, fechaFundada, sitioWeb, descripcion1, descripcion2, imagenFabricante, suspendido) 
VALUES 
('Nombre del Fabricante 1', 'País de Origen 1', 2000, 'http://www.sitioweb1.com', 'Descripción 1 del Fabricante 1', 'Descripción 2 del Fabricante 1', 'ruta/imagen1.jpg', 0);
