INSERT INTO nombre_de_la_tabla (nombreModelo, fechaFabricacion, tipoMoto, cilindrada, potencia1, potencia2, refrigeracion, tipoMotor, marchas, transmision, capacidad, arranque, tag, tipoCarnet, popularidad, precioMin, precioMax, descripcion, imagenMoto, suspendida, idFabricante) 
VALUES 
('Nombre del Modelo 1', '2024-05-12', 'Tipo de Moto 1', 1000, 150, 120, 'Refrigeración 1', 'Tipo de Motor 1', 6, 'Transmisión 1', 'Capacidad 1', 'Arranque 1', 'Tag 1', 'A', 5, 5000.00, 10000.00, 'Descripción del Modelo 1', 'ruta/imagen1.jpg', 0, 1);
