/*  */
SELECT DISTINCT nombreModelo 
FROM motocicleta;